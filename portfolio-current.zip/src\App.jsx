import { useState, useEffect, useRef } from 'react'
import { Github, ArrowUpRight, Image } from 'lucide-react'
import './App.css'
import './components/ProjectShowcase.css'
import './components/AboutSection.css'
import './components/FinalPolish.css'
import './components/HorizontalProjects.css'
import DeveloperConsole from './components/DeveloperConsole'
import PortfolioAnimations from './components/PortfolioAnimations'
import NeuralCore from './components/NeuralCore'
import InteractiveEffects from './components/InteractiveEffects'
import ProjectArtwork from './components/ProjectArtwork'
import ckdImage from './assets/projects/ckd-one.png'
import rosterImage from './assets/projects/smart-roster.png'
import schoolImage from './assets/projects/school-management.png'

const github = 'https://github.com/shaunak36'
const linkedin = 'https://www.linkedin.com/in/shaunak-paul-000907321/'
const resume = `${import.meta.env.BASE_URL}Shaunak-Paul-Resume.pdf`
const projects = [
 {number:'01',name:'KrishiAI',category:'AI / MOBILE APPLICATION',label:'AGRICULTURAL INTELLIGENCE',tagline:'Intelligence for agriculture.',description:'Offline crop disease detection using MobileNetV2 and TensorFlow Lite, with Firebase, Gemini and multilingual support.',technologies:['Flutter','TensorFlow Lite','Firebase','Gemini'],visual:'krishi',image:null,github:github+'/Krishi-Ai',demo:null},
 {number:'02',name:'CKD One',category:'MACHINE LEARNING / FULL STACK',label:'HEALTHCARE INTELLIGENCE',tagline:'Explainable intelligence for healthcare.',description:'An explainable CKD risk prediction platform combining XGBoost, SHAP, a Supabase relational database, FastAPI and Gemini-powered lab report extraction.',technologies:['Python','XGBoost','SHAP','FastAPI','Supabase','Next.js'],visual:'ckd',image:ckdImage,github:github+'/ckd-frontend',demo:'https://ckd-frontend-iota.vercel.app/en'},
 {number:'03',name:'SmartRoster AI',category:'FULL STACK / OPTIMIZATION',label:'WORKFORCE INTELLIGENCE',tagline:'Complex scheduling. Simplified.',description:'An intelligent workforce scheduling platform built around automated roster optimization, employee availability and operational constraints.',technologies:['React','FastAPI','OR-Tools'],visual:'roster',image:rosterImage,github:github+'/smartroster-ai',demo:'https://smartroster-ai.onrender.com'},
 {number:'04',name:'School Management AI',category:'FULL STACK / AI INTEGRATION',label:'EDUCATIONAL TECHNOLOGY',tagline:'A smarter learning experience.',description:'A school management platform with a React frontend, Node.js and Express REST backend, and LLM-powered grading, attendance analysis and student performance prediction.',technologies:['React','Node.js','Express','Groq','LLaMA'],visual:'school',image:schoolImage,github:github+'/shaunak36-school-management-frontend',demo:'https://school-management-ai.netlify.app'}
]
const highlights = {
 krishi: ['Offline crop disease detection using MobileNetV2.', 'On-device inference with TensorFlow Lite.', 'Multilingual assistance with Firebase and Gemini.'],
 ckd: ['CKD risk prediction using XGBoost and SHAP explanations.', 'FastAPI backend and Supabase relational database.', 'Gemini-powered lab report extraction.'],
 roster: ['Automated roster generation using OR-Tools.', 'Employee availability and operational constraints.', 'Conflict detection and workload balancing.'],
 school: ['AI-powered grading and attendance analysis.', 'Student performance prediction.', 'React frontend and Node.js / Express REST backend.'],
}
const skills = [
 ['01','Databases & backend',['SQL','Supabase','DBMS','Schema design','FastAPI','REST APIs']],
 ['02','Python & data',['Python','Pandas','NumPy','Data cleaning','Data normalization','Document data extraction']],
 ['03','Machine learning & AI',['Classification','Prediction','Cross-validation','XGBoost','Gemini','Groq / LLaMA']],
 ['04','Tools & deployment',['Git','GitHub','Render','Vercel','Netlify']]
]
function SocialLink({href,children}) {return <a className="profile-link" href={href} target="_blank" rel="noopener noreferrer">{children}<ArrowUpRight size={16}/></a>}
function App(){
 const [selectedProject,setSelectedProject]=useState(null)
 const dialogRef=useRef(null)
 useEffect(()=>{const dialog=dialogRef.current;const previousOverflow=document.body.style.overflow;if(selectedProject && dialog){if(!dialog.open)dialog.showModal();document.body.style.overflow='hidden'}return ()=>{document.body.style.overflow=previousOverflow}},[selectedProject])
 const closePreview=()=>{dialogRef.current?.close();setSelectedProject(null)}
 return <main className="portfolio">
 <a className="skip-link" href="#work">Skip to projects</a><PortfolioAnimations/><InteractiveEffects/>
 <nav className="navbar" aria-label="Main navigation"><a href="#" className="logo" aria-label="Shaunak Paul — home">SP<span>®</span></a><div className="nav-links"><a href="#work">WORK</a><a href="#about">ABOUT</a><a href="#contact">CONTACT</a></div><div className="availability"><span className="status-dot"/>AVAILABLE FOR WORK</div></nav>
 <section className="hero"><p className="eyebrow">PORTFOLIO / 2026</p><h1>SHAUNAK<br/><span>PAUL.</span></h1><NeuralCore/><div className="hero-bottom"><div className="hero-introduction"><p className="hero-role">AI &amp; Machine Learning Student</p><p className="intro">Exploring backend development, data analytics<br className="hero-copy-break"/> and intelligent applications.</p></div><div className="hero-actions"><a href="#work" className="profile-link resume-link">VIEW PROJECTS <span>↘</span></a><a href={resume} download="Shaunak-Paul-Resume.pdf" className="profile-link">DOWNLOAD RESUME <span>↓</span></a></div></div><div className="hero-index"><span>01 — INTRODUCTION</span><span>INDIA / 2026</span></div></section>
 <DeveloperConsole/>
 <section id="work" className="projects-section horizontal-projects">
  <div className="horizontal-stage">
   <div className="projects-heading"><p className="eyebrow">02 — SELECTED WORK</p><h2>Things I've built<span>.</span></h2><p className="projects-subtitle horizontal-hint">Scroll to explore <span>→</span></p></div>
   <div className="horizontal-viewport" tabIndex={0} aria-label="Project cards, scroll to explore" data-lenis-prevent-touch>
    <div className="horizontal-track">{projects.map(project => <article key={project.number} className={`horizontal-card ${project.visual}`}>
     <div className="horizontal-card-top"><span className="horizontal-number">{project.number}</span><span className="horizontal-category">{project.category}</span></div>
     <div className="horizontal-art"><ProjectArtwork type={project.visual}/></div>
     <h3>{project.name}<span>.</span></h3>
     <ul className="horizontal-highlights">{highlights[project.visual].map(point => <li key={point}>{point}</li>)}</ul>
     <div className="horizontal-tags">{project.technologies.map(tech => <span key={tech}>{tech}</span>)}</div>
     <div className="horizontal-actions">{project.demo && <a href={project.demo} target="_blank" rel="noopener noreferrer">LIVE DEMO <ArrowUpRight size={14}/></a>}<a href={project.github} target="_blank" rel="noopener noreferrer"><Github size={14}/> {project.visual === 'krishi' ? 'VIEW SOURCE' : 'GITHUB'}</a>{project.visual === 'krishi' && <span className="horizontal-project-status">Mobile app · Source available</span>}{project.image && <button type="button" onClick={()=>setSelectedProject(project)}><Image size={14}/> PREVIEW</button>}</div>
    </article>)}
    <article className="horizontal-card github-card">
      <div className="horizontal-card-top"><span className="horizontal-number">05</span><Github size={36} aria-hidden="true"/></div>
      <div className="github-card-content"><p className="horizontal-category">THE WORK CONTINUES</p><h3>More on GitHub<span>.</span></h3><p>Explore my other projects, experiments and ongoing work.</p><a className="github-card-link" href={github} target="_blank" rel="noopener noreferrer"><Github size={18}/> github.com/shaunak36 <ArrowUpRight size={18}/></a></div>
    </article></div>
   </div>
   <div className="horizontal-meter" aria-hidden="true"><span/></div>
  </div>
 </section>
 <section id="about" className="work-section profile-section"><p className="eyebrow">03 — ABOUT</p><h2>Curiosity meets technology<span>.</span></h2><p className="profile-intro">I'm a final-year Artificial Intelligence and Machine Learning student building skills in backend development, databases and data processing. I enjoy turning raw data into structured information and building applications that put it to work.</p><div className="profile-grid"><div className="profile-panel"><p className="profile-label">01 / EDUCATION</p><h3>B.E. Artificial Intelligence & Machine Learning</h3><p>St. John College of Engineering and Management, Palghar</p><p>University of Mumbai</p><span className="profile-meta">2023 — 2027 (EXPECTED) · SGPI 8.45 (SEM 5)</span></div><div className="profile-panel"><p className="profile-label">02 / EXPERIENCE</p><h3>AI Engineering Intern</h3><p>Branding Catalyst Pvt. Ltd.</p><p>Cleaned and structured student records for attendance and performance analytics, and collaborated on API integrations using Git and GitHub.</p></div></div><div className="profile-skills"><p className="profile-label">03 / TECHNICAL TOOLKIT</p><div className="profile-grid">{skills.map(([number,title,items])=><div className="skill-panel" key={number}><span className="profile-label">{number}</span><h3>{title}</h3><div className="skill-tags">{items.map(item=><span key={item}>{item}</span>)}</div></div>)}</div></div><div className="profile-actions"><a className="profile-link resume-link" href={resume} download="Shaunak-Paul-Resume.pdf">DOWNLOAD RESUME <span>↓</span></a><SocialLink href={github}>GITHUB</SocialLink><SocialLink href={linkedin}>LINKEDIN</SocialLink></div></section>
 <footer id="contact" className="footer"><p>04 — CONTACT / OPEN TO INTERNSHIPS</p><a href="mailto:paulshaunak5@gmail.com" className="contact-link">LET'S TALK<span>↗</span></a><p className="contact-note">Interested in database, backend and AI opportunities.</p><div className="profile-actions contact-actions"><a className="profile-link" href="mailto:paulshaunak5@gmail.com">EMAIL <ArrowUpRight size={16}/></a><SocialLink href={linkedin}>LINKEDIN</SocialLink><SocialLink href={github}>GITHUB</SocialLink></div><div className="footer-bottom"><p>© 2026 SHAUNAK PAUL</p><p>DESIGNED & BUILT WITH CURIOSITY.</p></div></footer>
 <dialog ref={dialogRef} className="lightbox" aria-labelledby="lightbox-title" onClose={()=>setSelectedProject(null)} onClick={event=>{if(event.target===event.currentTarget)closePreview()}}>{selectedProject && <div className="lightbox-content"><div className="lightbox-header"><div><p className="lightbox-label">PROJECT / {selectedProject.number}</p><h2 id="lightbox-title">{selectedProject.name}</h2></div><button type="button" className="lightbox-close" onClick={closePreview} aria-label="Close image preview">×</button></div><img src={selectedProject.image} alt={`${selectedProject.name} application screenshot`} className="lightbox-image"/><div className="lightbox-footer"><span>PROJECT PREVIEW / 2026</span><span>PRESS ESC TO CLOSE</span></div></div>}</dialog>
 </main>
}
export default App
